package com.example.campershaven;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class Place_DetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_details); // Layout for the place details

        // Get the extras from the intent
        String placeName = getIntent().getStringExtra("PLACE_NAME");
        int placeImageResId = getIntent().getIntExtra("PLACE_IMAGE", 0); // Default to 0 if not found
        String placeDescription = getIntent().getStringExtra("PLACE_DESCRIPTION"); // Get the description

        // Find the views to display the details
        TextView placeNameTextView = findViewById(R.id.place_name_text);
        ImageView placeImageView = findViewById(R.id.place_image_view);
        TextView placeDescriptionTextView = findViewById(R.id.place_description_text); // New TextView for description

        // Set the data to the views
        placeNameTextView.setText(placeName);
        placeImageView.setImageResource(placeImageResId);
        placeDescriptionTextView.setText(placeDescription); // Set the description

        ImageView shoppycart = findViewById(R.id.shoppycart);
        shoppycart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Place_DetailsActivity.this, CartActivity.class);
                startActivity(intent);
            }
        });

        Toolbar toolbar = findViewById(R.id.barmenu);
        setSupportActionBar(toolbar);

        // Add a menu icon on the right side
        toolbar.setNavigationIcon(R.drawable.rectangle_1); // Replace with your icon

        // Set click listener for the icon
        toolbar.setNavigationOnClickListener(view -> showPopupMenu(view));
    }

    // Method to show PopupMenu
    private void showPopupMenu(View view) {
        PopupMenu popupMenu = new PopupMenu(this, view);
        popupMenu.getMenuInflater().inflate(R.menu.right_side_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(menuItem -> {
            int itemId = menuItem.getItemId();

            if (itemId == R.id.action_home) {
                handleHome();
                return true;
            } else if (itemId == R.id.action_profile) {
                handleProfile();
                return true;
            } else if (itemId == R.id.action_settings) {
                handleSettings();
                return true;
            } else if (itemId == R.id.action_logout) {
                handleLogout();
                return true;
            } else {
                return false;
            }
        });

        popupMenu.show();
    }

    private void  handleHome(){
        Intent intent = new Intent(Place_DetailsActivity.this, MainActivity.class); // Replace with actual profile activity
        startActivity(intent);
    }
    // Profile handling
    private void handleProfile() {
        // Perform actions related to the profile, e.g., navigate to ProfileActivity
        Intent intent = new Intent(Place_DetailsActivity.this, ProfileActivity.class); // Replace with actual profile activity
        startActivity(intent);
    }

    // Settings handling
    private void handleSettings() {
        // Perform actions related to settings, e.g., navigate to SettingsActivity
        Intent intent = new Intent(Place_DetailsActivity.this, SettingsActivity.class); // Replace with actual settings activity
        startActivity(intent);
    }

    // Logout handling
    private void handleLogout() {
        // Perform logout actions, such as clearing user data or redirecting to login screen
        Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(Place_DetailsActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();

    }
}

