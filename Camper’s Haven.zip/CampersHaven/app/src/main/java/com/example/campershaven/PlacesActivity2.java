package com.example.campershaven;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class PlacesActivity2 extends AppCompatActivity {

    private LinearLayout placesContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_places2); // Ensure this matches your layout file name

        placesContainer = findViewById(R.id.places_container); // Initialize placesContainer

        // Example of adding places with descriptions
        addPlace("Nethravali Waterfall", R.drawable.nethravali_waterfall_goa_1, "Nethravali waterfall is in Sanguem Taluk, which is one of the best places that you should not miss in Goa. The greenery and the rocks around the waterfall multiply its beauty.\n" +
                "\n" +
                "Best Time to Visit: July to November.\n" +
                "How to Reach: Located in the Netravali Wildlife Sanctuary, about 65 km from Panaji. It’s accessible by road from Margao.\n" +
                "Why Visit: This waterfall is nestled in the dense forests of the sanctuary and is ideal for those looking for a peaceful escape in nature.\n" +
                "Things to Do: Trek through the sanctuary, enjoy bird-watching, and swim in the cool waters of the falls..");
        addPlace("Kerala", R.drawable.forestcampingimage_2, "Kerala is famous for its backwaters and lush green landscapes.");
        addPlace("Himachal", R.drawable.himachalcampingimage_3, "Himachal Pradesh is known for its stunning mountains and adventure sports.");
    }

    private void addPlace(String name, int imageResId, String description) {
        // Inflate the card layout
        LayoutInflater inflater = LayoutInflater.from(this);
        View cardView = inflater.inflate(R.layout.card_place, placesContainer, false);

        // Set the image and text
        ImageView placeImage = cardView.findViewById(R.id.place_image);
        TextView placeName = cardView.findViewById(R.id.place_name);
        LinearLayout cardLayout = cardView.findViewById(R.id.card_layout); // Reference to the clickable layout

        placeImage.setImageResource(imageResId);
        placeName.setText(name);

        // Set up click listener for the whole card layout
        cardLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PlacesActivity2.this, Place_DetailsActivity.class);
                intent.putExtra("PLACE_NAME", name);
                intent.putExtra("PLACE_IMAGE", imageResId);
                intent.putExtra("PLACE_DESCRIPTION", description); // Pass the description
                startActivity(intent);
            }
        });

        // Add the card view to the container
        placesContainer.addView(cardView);

        ImageView cartshop = findViewById(R.id.cartshop);
        cartshop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PlacesActivity2.this, CartActivity.class);
                startActivity(intent);
            }
        });

        Toolbar toolbar = findViewById(R.id.menubar);
        setSupportActionBar(toolbar);

        // Add a menu icon on the right side
        toolbar.setNavigationIcon(R.drawable.rectangle_1); // Replace with your icon

        // Set click listener for the icon
        toolbar.setNavigationOnClickListener(view -> showPopupMenu(view));
    }

    // Method to show PopupMenu
    private void showPopupMenu(View view) {
        PopupMenu popupMenu = new PopupMenu(this, view);
        popupMenu.getMenuInflater().inflate(R.menu.right_side_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(menuItem -> {
            int itemId = menuItem.getItemId();

            if (itemId == R.id.action_home) {
                handleHome();
                return true;
            } else if (itemId == R.id.action_profile) {
                handleProfile();
                return true;
            } else if (itemId == R.id.action_settings) {
                handleSettings();
                return true;
            } else if (itemId == R.id.action_logout) {
                handleLogout();
                return true;
            } else {
                return false;
            }
        });

        popupMenu.show();
    }

    private void  handleHome(){
        Intent intent = new Intent(PlacesActivity2.this, MainActivity.class); // Replace with actual profile activity
        startActivity(intent);
    }
    // Profile handling
    private void handleProfile() {
        // Perform actions related to the profile, e.g., navigate to ProfileActivity
        Intent intent = new Intent(PlacesActivity2.this, ProfileActivity.class); // Replace with actual profile activity
        startActivity(intent);
    }

    // Settings handling
    private void handleSettings() {
        // Perform actions related to settings, e.g., navigate to SettingsActivity
        Intent intent = new Intent(PlacesActivity2.this, SettingsActivity.class); // Replace with actual settings activity
        startActivity(intent);
    }

    // Logout handling
    private void handleLogout() {
        // Perform logout actions, such as clearing user data or redirecting to login screen
        Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(PlacesActivity2.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
