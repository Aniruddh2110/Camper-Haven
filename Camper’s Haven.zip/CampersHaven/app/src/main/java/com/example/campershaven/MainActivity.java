package com.example.campershaven;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private LinearLayout containerLayout;
    private List<Product> productList;
    private List<Product> filteredList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize toolbar and set up menu icon
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.rectangle_1); // replace with your icon
        toolbar.setNavigationOnClickListener(view -> showPopupMenu(view));

        // Initialize UI components
        containerLayout = findViewById(R.id.containerLayout);
        SearchView searchView = findViewById(R.id.searchView);
        ConstraintLayout placebtn = findViewById(R.id.placebtn);

        // Set up navigation button to PlacesActivity2
        placebtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, PlacesActivity2.class);
            startActivity(intent);
        });

        ImageView shopCart = findViewById(R.id.shopCart);

        // Set up navigation button to PlacesActivity2
        shopCart.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CartActivity.class);
            startActivity(intent);
        });

        // Initialize product list and populate it
        initializeProductList();
        filteredList = new ArrayList<>(productList);
        displayProducts(filteredList);

        // Set up search filter
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                filterProducts(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterProducts(newText);
                return false;
            }
        });
    }

    // Initialize product list with sample data
    private void initializeProductList() {
        productList = new ArrayList<>();
        productList.add(new Product("Olievier Tent", "2000Rs", R.drawable._982f9a6_96aa_4467_b258_649f460b7c34_1_1));
        productList.add(new Product("Olievier Stove", "1300Rs", R.drawable._7590b163c0d57beadad9962e9450ac7_1));
    }

    // Show PopupMenu on toolbar icon click
    private void showPopupMenu(View view) {
        PopupMenu popupMenu = new PopupMenu(this, view);
        popupMenu.getMenuInflater().inflate(R.menu.right_side_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(menuItem -> {
            int itemId = menuItem.getItemId();

            if (itemId == R.id.action_home) {
                Toast.makeText(this, "Home clicked", Toast.LENGTH_SHORT).show();
                return true;
            } else if (itemId == R.id.action_profile) {
                handleProfile();
                return true;
            } else if (itemId == R.id.action_settings) {
                handleSettings();
                return true;
            } else if (itemId == R.id.action_logout) {
                handleLogout();
                return true;
            } else {
                return false;
            }
        });

        popupMenu.show();
    }

    // Profile handling
    private void handleProfile() {
        // Perform actions related to the profile, e.g., navigate to ProfileActivity
        Intent intent = new Intent(MainActivity.this, ProfileActivity.class); // Replace with actual profile activity
        startActivity(intent);
    }

    // Settings handling
    private void handleSettings() {
        // Perform actions related to settings, e.g., navigate to SettingsActivity
        Intent intent = new Intent(MainActivity.this, SettingsActivity.class); // Replace with actual settings activity
        startActivity(intent);
    }

    // Logout handling
    private void handleLogout() {
        // Perform logout actions, such as clearing user data or redirecting to login screen
        Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    // Filter products based on search query
    private void filterProducts(String query) {
        filteredList.clear();
        for (Product product : productList) {
            if (product.getName().toLowerCase().contains(query.toLowerCase()) ||
                    product.getPrice().toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(product);
            }
        }
        displayProducts(filteredList);
    }

    // Display products in the UI
    private void displayProducts(List<Product> productsToShow) {
        containerLayout.removeAllViews();
        for (int i = 0; i < productsToShow.size(); i += 2) {
            LinearLayout rowLayout = createRowLayout();

            // Inflate and add the first product card
            Product product1 = productsToShow.get(i);
            View productCard1 = createProductCard(rowLayout, product1);
            rowLayout.addView(productCard1);

            // Set click listener for the first product card
            productCard1.setOnClickListener(v -> openProductDetails(product1));

            // Inflate and add the second product card if it exists
            if (i + 1 < productsToShow.size()) {
                Product product2 = productsToShow.get(i + 1);
                View productCard2 = createProductCard(rowLayout, product2);
                rowLayout.addView(productCard2);

                // Set click listener for the second product card
                productCard2.setOnClickListener(v -> openProductDetails(product2));
            }

            // Add the row layout to the main container
            containerLayout.addView(rowLayout);
        }
    }

    // Create a row layout to hold two product cards
    private LinearLayout createRowLayout() {
        LinearLayout rowLayout = new LinearLayout(this);
        rowLayout.setOrientation(LinearLayout.HORIZONTAL);
        rowLayout.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        return rowLayout;
    }

    // Create a product card view
    private View createProductCard(LinearLayout rowLayout, Product product) {
        View productCard = LayoutInflater.from(this).inflate(R.layout.product_card, rowLayout, false);
        ImageView imageView = productCard.findViewById(R.id.productImage);
        TextView nameView = productCard.findViewById(R.id.productName);
        TextView priceView = productCard.findViewById(R.id.productPrice);
        imageView.setImageResource(product.getImageResId());
        nameView.setText(product.getName());
        priceView.setText(product.getPrice());
        return productCard;
    }

    // Open product details in a new activity
    private void openProductDetails(Product product) {
        Intent intent = new Intent(MainActivity.this, ProductActivity.class);
        intent.putExtra("productName", product.getName());
        intent.putExtra("price", product.getPrice());
        intent.putExtra("imageResId", product.getImageResId());
        startActivity(intent);
    }
}
