package com.example.campershaven;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class SplashActivity extends AppCompatActivity {

    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        auth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = auth.getCurrentUser();

        if (currentUser != null) {
            // User is already logged in, go to MainActivity
            startActivity(new Intent(SplashActivity.this, MainActivity.class));
            finish();
        } else {
            // User is not logged in, go to LoginActivity
            startActivity(new Intent(SplashActivity.this, LoginActivity.class));
            finish();
        }
    }
}
